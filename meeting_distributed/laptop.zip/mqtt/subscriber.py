import json

import paho.mqtt.client as mqtt

import config

from planner.problem_generator import generate_problem
from planner.run_planner import run_planner

from mqtt.publisher import publish_action


def on_message(client, userdata, msg):

    state = json.loads(msg.payload.decode())

    with open(config.STATE_FILE, "w") as f:

        json.dump(state, f)

    print()

    print("Received state:", state)

    generate_problem()

    actions = run_planner()

    print("Planner actions:", actions)

    for action in actions:

        publish_action(action)


client = mqtt.Client()

client.on_message = on_message

client.connect(config.MQTT_BROKER)

client.subscribe(config.MQTT_STATE_TOPIC)