
(define (problem meeting-room-problem)

(:domain meeting-room)

(:init
    (occupied) (light-on) (comfortable) (air-quality-good) (fan-off)
)

(:goal
    (and
        (light-on) (fan-off)
    )
)

)
